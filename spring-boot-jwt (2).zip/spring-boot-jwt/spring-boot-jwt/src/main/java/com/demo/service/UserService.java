package com.demo.service;

import com.demo.model.User;

public class UserService {

	public void save(User user) {
		
	}

}
